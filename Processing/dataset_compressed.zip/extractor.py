# Использование: unpack("путь\\имя_файла.pck"). Возвращает массив матриц 16x16  

def decompress(r, height, width):
    out = []
    for i in r:
        column = []
        for digit in range(0, height):
            if int(i/(pow(2, digit)))%2 == 1:
                column.append(0)
            else:
                column.append(255)
        out.append(column)
    return out

def unpack(file):
    f = open(file,"r")
    string = f.read()
    split = string.split()
    split = [int(i) for i in split]
    height = split[0]
    width = split[1]
    f.close()
    file = []
    for i in range(0, int((len(split)-2)/width)):
        #for x in range(0, width):
        picture = (decompress(split[2+i*width:2+i*width+width], height, width))
        file.append(picture)
    return file
